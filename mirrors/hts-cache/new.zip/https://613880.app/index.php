<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>138搜索</title>
  <link rel="stylesheet" href="css/vendors.css?v=3">
  <link rel="stylesheet" href="css/style.css?v=4">
  <script src="lib/jquery.min.js"></script>
  <script src="lib/materialize.min.js"></script>
  <script src="lib/clipboard.min.js"></script>
  <script src="lib/jquery.dataTables.js"></script>
  <script src="js/bundle.js"></script>
  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-153796581-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-153796581-1');
</script>
</head>

<body class="index">


  <!-- header -->
  <nav>
    <div class="navbar-fixed">
      <div class="container">
        <a class="logo-header"><img src="img/smalllogo.png" /></a>
        <div class="link-list">
          <div class="link-item"><a href="http://www.icbc.com.cn/icbc/" target="_blank">工商银行</a></div>
          <div class="link-item"><a href="http://www.95599.cn/cn/" target="_blank">农业银行</a></div>
          <div class="link-item"><a href="http://www.ccb.com/cn/home/index.html" target="_blank">建设银行</a></div>
          <div class="link-item"><a href="http://www.95559.com.cn/" target="_blank">交通银行</a></div>
          <div class="link-item"><a href="http://www.boc.cn/" target="_blank">中国银行</a></div>
          <div class="link-item"><a href="http://www.cmbchina.com/" target="_blank">招商银行</a></div>
          <div class="link-item"><a href="http://www.psbc.com/portal/zh_CN/index.html" target="_blank">邮政银行</a></div>
          <div class="link-item"><a href="http://www.cmbc.com.cn/" target="_blank">民生银行</a></div>
        </div>
         <ul class="action">
          <a class="modal-trigger waves-effect waves-light btn transparent z-depth-0" data-target="modal-login"
            data-tab="modal1">
            <i class="material-icons left">person</i>
            <span>登录</span>
          </a>
          <a class="modal-trigger waves-effect waves-light btn transparent z-depth-0" data-target="modal-login"
            data-tab="modal2">注册</a>
        </ul>
      </div>
    </div>
  </nav>

  <main>
    <div class="container">
      <div class="row center">
        <img class="main-logo" src="img/logo-animate.gif">
      </div>
	  
	  <form method="post" class="row search-form" action="/index.php" id="contact_form">
	  <input type="hidden" name="do" value="contact">
        <div class="input-field search-field s12 m9 l8 offset- z-depth-1" style="width: 100%; z-index:999">
          <input type="text" name="search" id="search-field" class="browser-default">
          <!-- <label for="search-field">请输入内容</label> -->
        </div>
		
		<div style="width: 270px; margin-left: 50%; left: -135px; position: relative;">
		<div id='captcha_container_1'>
<img style="float: left; padding-right: 5px" id="captcha_image" src="/securimage_show.php?1417899e39b2feaefedc90574e31228a" alt="CAPTCHA Image" /><div id="captcha_image_audio_div">
<audio id="captcha_image_audio" preload="none" style="display: none">
<source id="captcha_image_source_wav" src="/securimage_play.php?id=62d2ddbf26ee0" type="audio/wav">
<object type="application/x-shockwave-flash" data="/securimage_play.swf?bgcol=%23ffffff&amp;icon_file=%2Fimages%2Faudio_icon.png&amp;audio_file=%2Fsecurimage_play.php%3F" height="32" width="32"><param name="movie" value="/securimage_play.swf?bgcol=%23ffffff&amp;icon_file=%2Fimages%2Faudio_icon.png&amp;audio_file=%2Fsecurimage_play.php%3F"></object><br /></audio>
</div>
<div id="captcha_image_audio_controls">
<a tabindex="-1" class="captcha_play_button" href="/securimage_play.php?id=62d2ddbf26ee7" onclick="return false">
<img class="captcha_play_image" height="32" width="32" src="/images/audio_icon.png" alt="Play CAPTCHA Audio" style="border: 0px">
<img class="captcha_loading_image rotating" height="32" width="32" src="/images/loading.png" alt="Loading audio" style="display: none">
</a>
<noscript>Enable Javascript for audio controls</noscript>
</div>
<script type="text/javascript" src="/securimage.js"></script>
<script type="text/javascript">captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });</script>
<a tabindex="-1" style="border: 0" href="#" title="Refresh Image" onclick="if (typeof window.captcha_image_audioObj !== 'undefined') captcha_image_audioObj.refresh(); document.getElementById('captcha_image').src = '/securimage_show.php?' + Math.random(); this.blur(); return false"><img height="32" width="32" src="/images/refresh.png" alt="Refresh Image" onclick="this.blur()" style="border: 0px; vertical-align: bottom"></a><br><div style="clear: both"></div><label for="captcha_code">输入文字</label> <input type="text" name="ct_captcha" id="captcha_code" autocomplete="off" >
</div>
		</div>
		
		<div class="input-field">
          <button type="submit" class="btn-large" style="width: 300px; margin-left: 50%; left: -150px; position: relative;">搜索一下</button>
        </div>
		
      </form>
    </div>
  </main>


  <footer class="page-footer">
    <div class="container">
      <div class="row">
        <div class="col s12 center footer-link-list">
          <a href="http://www.icbc.com.cn/icbc/" target="_blank">
            <div class="chip white">工商银行</div>
          </a>
          <a href="http://www.95599.cn/cn/" target="_blank">
            <div class="chip white">农业银行</div>
          </a>
          <a href="http://www.ccb.com/cn/home/index.html" target="_blank">
            <div class="chip white">建设银行</div>
          </a>
          <a href="http://www.95559.com.cn/" target="_blank">
            <div class="chip white">交通银行</div>
          </a>
          <a href="http://www.boc.cn/" target="_blank">
            <div class="chip white">中国银行</div>
          </a>
          <a href="http://www.cmbchina.com/" target="_blank">
            <div class="chip white">招商银行</div>
          </a>
          <a href="http://www.psbc.com/portal/zh_CN/index.html" target="_blank">
            <div class="chip white">邮政银行</div>
          </a>
          <a href="http://www.cmbc.com.cn/" target="_blank">
            <div class="chip white">民生银行</div>
          </a>
        </div>
      </div>
      <div>
        <p class="center">
          © 2018 Copyright 138导航
        </p>
      </div>
    </div>
  </footer>
  <!-- 登录、注册 start-->
  <div id="modal-login" class="modal">
    <div class="modal-header">
      <div class="row">
        <ul class="tabs transparent col s12">
          <li class="tab col s6 l6"><a class="materialize-gray-text active" href="#modal1">用户登录</a></li>
          <li class="tab col s6 l6"><a href="#modal2">免费注册</a></li>
        </ul>
      </div>
    </div>
    <form id="modal1" class="active">
      <div class="modal-content">
        <span class="welcome">欢迎来到138导航网!</span>
        <div class="input-field col s12">
          <!-- <i class="material-icons prefix">person</i> -->
          <input type="text" name="txtUserName" id="txtUserName" class="validate"  tabindex="1">
          <label for="txtUserName">用户帐号</label>
        </div>
        <div class="input-field col s12">
          <!-- <i class="material-icons prefix">lock</i> -->
          <input type="password" name="txtUserPwd" id="txtUserPwd" class="validate"  tabindex="2">
          <label for="txtUserPwd">用户密码</label>
        </div>
        <span class="small">客服电邮:138138tt@gmail.com</span>
      </div>
      <div class="modal-footer">
        <a href="#!" class="modal-close waves-effect waves-light btn-flat">取消</a>
        <a href="javascript:void (0);" class="waves-effect waves-light btn-flat blue-text login">登录</a>
      </div>
    </form>
    <form id="modal2">
      <div class="modal-content">
        <span class="welcome">创建您的138导航网帐户</span>
        <div class="input-field col s12">
          <!-- <i class="material-icons prefix">person</i> -->
          <input type="text" name="userName" id="userName" class="validate">
          <label for="userName">用户帐号</label>
          <span class="helper-text">由3-20个数字字符组成</span>
        </div>
        <div class="input-field col s12">
          <!-- <i class="material-icons prefix">lock</i> -->
          <input type="password" name="userPwd" id="userPwd" class="validate">
          <label for="userPwd">用户密码</label>
          <span class="helper-text">6位数以上</span>
        </div>
        <div class="input-field col s12">
          <!-- <i class="material-icons prefix">lock</i> -->
          <input type="password" name="userPwd1" id="userPwd1" class="validate">
          <label for="userPwd1">确认密码</label>
          <span class="helper-text">密码二次确认</span>
        </div>
        <div class="input-field col s12">
          <!-- <i class="material-icons prefix">mail</i> -->
          <input type="email" name="userEmail" id="userEmail" class="validate">
          <label for="userEmail">电子邮箱</label>
          <span class="helper-text materialize-red-text">请务必填写真实邮箱，方便急换网址时候通知您！</span>
        </div>
      </div>
      <div class="modal-footer">
        <a href="#!" class="modal-close waves-effect waves-light btn-flat">取消</a>
        <a href="javascript:void (0);" class="waves-effect waves-light btn-flat blue-text register">注册</a>
      </div>
    </form>
  </div>
  <!-- 登录、注册 end-->
</body>

</html>

<script>




$(".login").click(function(e) {
	$.post('ajax/login.php', $("#modal1").serialize(), 
	function(data){
		if (data.code == "1") {
			window.location  ="user-page-domain.php";
		} else {
			M.toast({html: data.msg});
		} 
		
		document.getElementById('modal1').reset();
		
	}, "json").fail(function() {
        alert( "Posting failed." );
	});
});

$(".register").click (function (e) {
	var userName = $("#userName").val ();
	var userPass1 = $("#userPwd").val ();
	var userPass2 = $("#userPwd1").val ();
	var userEmail = $("#userEmail").val ();
	
	
	if (userName == "") {
		M.toast({html: "请填写用户名"});
		$("#userName").focus ();
	} else if (userName.length < 3 || userName.length > 20) {
		M.toast({html: "用户名必须大于3个字符且小于20个字符"});
		$("#userName").focus ();
	} else if (userPass1 == "") {
		M.toast({html: "请填写密码"});
		$("#userPwd").focus ();
	} else if (userPass2 == "") {
		M.toast({html: "请填写重复密码"});
		$("#userPwd1").focus ();
	} else if (userPass1 != userPass2) {
		M.toast({html: "密码不一样"});
	} else if (emailValidation(userEmail) == false) {
		M.toast({html: "请输入有效的电子邮件地址"});
		$("#userEmail").focus ();
	} else {
		$.post('ajax/register.php', $("#modal2").serialize(), 
		function(data){
			if (data.code == "1") {
				alert (data.msg);
				window.location  ="user-page-domain.php";
			} else {
				M.toast({html: data.msg});
			} 
			
			
		}, "json").fail(function() {
			alert( "Posting failed." );
		});
	}
	
});

$(".submit-search").click (function (evt) {
	evt.preventDefault();
	$(".searchform").submit ();
});

</script>

