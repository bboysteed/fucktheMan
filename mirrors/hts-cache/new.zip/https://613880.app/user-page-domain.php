<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>138搜索</title>
  <link rel="stylesheet" href="css/vendors.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="lib/jquery.min.js"></script>
  <script src="lib/materialize.min.js"></script>
  <script src="lib/clipboard.min.js"></script>
  <script src="lib/jquery.dataTables.js"></script>
  <script src="js/bundle.js"></script>
</head>

<body class="user">


  <nav>
    <div class="navbar-fixed">
      <div class="container">
        <a href="/" class="brand-logo main-logo left"><img src="img/smalllogo.png" /></a>
        <div class="user-info">
          <span class="username">
            您好，
            <strong></strong>
          </span>
          <span class="profile-icon">
            <i class="material-icons">account_circle</i>
            <div class="user-info-dropdown">
              <ul>
                <li>
                  <a href="logout.php">退出</a>
                </li>
                <li class="mobile">
                  <a href="/">首页</a>
                </li>
              </ul>
            </div>
          </span>
        </div>
      </div>
      <div class="mobile">
        <div class="container">
          <a class="active" href="#!">
            <span>导航管理</span>
          </a>
          <a href="user-page-profile.php">
            <span>个人资料</span>
          </a>
        </div>
      </div>
    </div>
  </nav>

  <main>
    <div class="container">
      <div class="sidebar-menu">
        <ul>
          <li>
            <a href="/">
              <h3>首页</h3>
            </a>
          </li>
          <li class="active">
            <a href="#!">
              <h3>导航管理</h3>
            </a>
          </li>
          <li>
            <a href="user-page-profile.php">
              <h3>个人资料</h3>
            </a>
          </li>
        </ul>
      </div>

      <div class="main-content user-domain-management">
        <h1 class="page-title">
          导航管理
        </h1>
        <div class="search-area">
          <div class="search-area-list">
            <div class="list-item">
              <label>
                <input type="checkbox" class="select-all filled-in" /><span>全选</span>
              </label>
            </div>
            <div class="list-item">
              <a class="modal-trigger waves-effect waves-effect btn-flat btn transparent" data-target="modal-add" href="#!">
                <i class="material-icons">add</i> 新增
              </a>
              <a class="waves-effect btn-flat submit-delete-site" href="#">
                <i class="material-icons">delete_forever</i> 删除
              </a>
            </div>
          </div>
        </div>
        <div class="cards-wrapper">
<form id="deleteSiteForm" class="">
</form>	  
		  
        </div>
      </div>
    </div>
  </main>




  <!-- Modal -->
  <div id="modal-add" class="modal">
    <div class="modal-content modal-header">
      <div class="row">
        <h6 class="col">新增</h6>
      </div>
    </div>
    <form id="addNewSiteForm" class="">
      <div class="modal-content">
        <div class="row">
          <div class="input-field col s12 m9">
            <input type="text" name="siteName" class="siteName">
            <label for="siteName">网站名称</label>
            <div class="helper-text">网站名称最多20个字符</div>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s9 m6">
            <!-- <i class="material-icons prefix">lock</i> -->
            <input type="text" name="siteToken" class="siteToken">
            <label for="siteToken"  class="siteTokenlabel">安全码</label>
            <div class="helper-text">安全码5到8个字符</div>
          </div>
          <div class="input-field col s3">
            <div class="generate btn-full">
              随机生成
            </div>
          </div>
        </div>
        <div class="row">
          <div class="input-field col radio-selection">
            <div class="helper-text">显示AB开奖网址</div>
            <span>
              <label>
                <input class="with-gap" name="group1" type="radio" checked="checked" value="yes"/>
                <span>是</span>
              </label>
            </span>
            <span>
              <label>
                <input class="with-gap" name="group1" type="radio" />
                <span>否</span>
              </label>
            </span>
          </div>
        </div>
		
		<div class="row">
          <div class="input-field col s6">
            <div class="helper-text">公告</div>
          </div>
          <div class="input-field col s6">
            <a id="addAnnouncement" href="#!" class="right">
              <i class="material-icons">add</i> 增加
            </a>
          </div>
        </div>
		<div class="site-announcement-group">
          <div class="row">
            <div class="input-field col s12">
              <input type="text" name="announcement[]">
              <label for="announcement">公告内容</label>
            </div>
			<input name="regdate2[]" type="hidden" value="">
            <div class="remove">
              <i class="material-icons">remove_circle_outline</i>
            </div>
          </div>
        </div>
		
        <div class="row">
          <div class="input-field col s6">
            <div class="helper-text">端口名称/网址</div>
          </div>
          <div class="input-field col s6">
            <a id="addSite" href="#!" class="right">
              <i class="material-icons">add</i> 增加
            </a>
          </div>
        </div>
        <div class="site-name-group">
          <div class="row">
            <div class="input-field col s3">
              <input type="text" name="webName[]"  class="webName">
              <label for="webName" class="active">端口名称</label>
            </div>
            <div class="input-field col s9">
              <input type="text" name="webDomain[]" class="webDomain" >
              <label for="webDomain" class="active">网址</label>
			  <div class="helper-text">网址前面记得加上http://或https://</div>
            </div>
            <div class="remove">
              <i class="material-icons">remove_circle_outline</i>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <div class="row">
          <div class="col right">
            <button type="reset" href="#!" class="modal-close waves-effect btn-flat">取消</button>
            <button class="waves-effect blue-text btn-flat submit-save-site">保存</button>
          </div>
        </div>
      </div>
    </form>
  </div>

  <div id="modal-edit" class="modal">
    <div class="modal-content modal-header">
      <div class="row">
        <h6 class="col">编辑</h6>
      </div>
    </div>
    <form id="editSiteForm" class="">
     
    </form>
  </div>

</body>

<script>

$(".modaledit").click (function () {
	var current_id = $(this).data("id");
	
	$( "#editSiteForm" ).load( "ajax/load-site.php?siteid=" + current_id, function() {
	  $('#modal-edit').modal('open');
	});
});

function makeid2() {
  var text = "";
  var possible1 = "0123456789";
  var possible2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

  for (var i = 0; i < 6; i++) {
    text += possible1.charAt(Math.floor(Math.random() * possible1.length));
  }
  
  for (var i = 0; i < 2; i++) {
    text += possible2.charAt(Math.floor(Math.random() * possible2.length));
  }

  return text;
}






$('body').on('click', '.submit-update-site', function(evt) {
	 evt.preventDefault();
	var siteName = $(this).parent().parent().parent().parent().find("input[name=siteName]").val();
	var siteToken = $(this).parent().parent().parent().parent().find("input[name=siteToken]").val();
	webName = $(this).parent().parent().parent().parent().find(".webName");
	webDomain = $(this).parent().parent().parent().parent().find(".webDomain");
	var siteNamel = siteName.length;
	var siteTokenl = siteToken.length;
	var webnameerror = false;
	var weburlerror = false;
	
	$(webName).each(function( index ) {
		if ($(this).val() == "") {
			webnameerror = true;
		}
	});
	
	$(webDomain).each(function( index ) {
		var str = $(this).val();
		str = str.split(' ').join('');
		$(this).val(str);
		
		if (validURL ($(this).val()) == false) {
			weburlerror = true;
		}
	});
	
	if (siteName == "") {
		M.toast({html: '请输入姓名'});
	} else if (siteNamel > 20) {
		M.toast({html: '请输入小于20个字符的站点名称'});
	} else if (siteTokenl < 5) {
		M.toast({html: '请输入安全码5或8个字符'});
	} else if (siteTokenl > 8) {
		M.toast({html: '请输入安全码5或8个字符'});
	} else if (webnameerror == true) {
		M.toast({html: '请输入网站名称'});
	} else if (weburlerror == true) {
		M.toast({html: '请输入有效的网站网址'});
	} else {
		$.post('ajax/update-site.php', $("#editSiteForm").serialize(), 
		function(data){
			if (data.code == "1") {
				alert (data.msg);
				location.reload();
			} else {
				M.toast({html: data.msg});
			} 
			
		}, "json").fail(function() {
			alert( "Posting failed." );
		});
	}

});

$('body').on('click', '.submit-save-site', function(evt) {
	 evt.preventDefault();
	var siteName = $(this).parent().parent().parent().parent().find("input[name=siteName]").val();
	var siteToken = $(this).parent().parent().parent().parent().find("input[name=siteToken]").val();
	webName = $(this).parent().parent().parent().parent().find(".webName");
	webDomain = $(this).parent().parent().parent().parent().find(".webDomain");
	var siteNamel = siteName.length;
	var siteTokenl = siteToken.length;
	var webnameerror = false;
	var weburlerror = false;
	
	$(webName).each(function( index ) {
		if ($(this).val() == "") {
			webnameerror = true;
		}
	});
	
	$(webDomain).each(function( index ) {
		var str = $(this).val();
		str = str.split(' ').join('');
		$(this).val(str);
		
		if (validURL ($(this).val()) == false) {
			weburlerror = true;
		}
	});
	
	if (siteName == "") {
		M.toast({html: '请输入姓名'});
	} else if (siteNamel > 20) {
		M.toast({html: '请输入小于20个字符的站点名称'});
	} else if (siteTokenl < 5) {
		M.toast({html: '请输入安全码5或8个字符'});
	} else if (siteTokenl > 8) {
		M.toast({html: '请输入安全码5或8个字符'});
	} else if (webnameerror == true) {
		M.toast({html: '请输入网站名称'});
	} else if (weburlerror == true) {
		M.toast({html: '请输入有效的网站网址'});
	} else {
		$.post('ajax/save-site.php', $("#addNewSiteForm").serialize(), 
		function(data){
			if (data.code == "1") {
				alert (data.msg);
				location.reload();
			} else {
				M.toast({html: data.msg});
			} 
			
		}, "json").fail(function() {
			alert( "Posting failed." );
		});
	}

});

$('body').on('click', '.submit-delete-site', function(evt) {
	var checkboxtest = false;
	$(".checksiteid").each(function( index ) {
		if ($(this).prop ("checked") == true) {
			checkboxtest = true;
		}
	});
	
	if (checkboxtest == true) {
		var r = confirm("你确认要删除吗？");
		if (r == true) {
			$.post('ajax/delete-site.php', $("#deleteSiteForm").serialize(), 
			function(data){
				if (data.code == "1") {
					alert (data.msg);
					location.reload();
				} else {
					M.toast({html: data.msg});
				} 
				
			}, "json").fail(function() {
				alert( "Posting failed." );
			});
		}	
	} else {
		M.toast({html: "Please select a checkbox"});
	}
	
});

$(".select-all").click (function () {
	if ($(this).prop ("checked") == true) {
		$(".checksiteid").prop( "checked", true );
	} else {
		$(".checksiteid").prop( "checked", false );
	}
});


$('body').on('click', '.generate', function(evt) {
	$(this).parent().parent().find (".siteTokenlabel").addClass( "active" );
	$(this).parent().parent().find (".siteToken").val (makeid2());
});

$(".visitsite").click (function () {
	var securitycode = $(this).attr ("rel");
	window.open("user-search-result.php?search=" + securitycode);
});



</script>